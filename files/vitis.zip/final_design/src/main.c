#include <stdio.h>
#include "xparameters.h"
#include "xil_printf.h"
#include "sleep.h"

#include "../libs/I2C_PS/i2c_ps.h"
#include "../libs/SII9022/sii9022_init.h"
#include "../libs/GPIO/Gpio.h"
#include "../libs/TPG/Tpg.h"
#include "../libs/VFB/Vfb.h"

#define OPERATION_SOURCE 0x11000000
#define OPERATION_DESTINATION 0x12000000

#define HDMI_WIDTH 640
#define HDMI_HEIGHT 480
#define HDMI_STRIDE (HDMI_WIDTH * 3)
#define HDMI_DEFAULT_PATTERN tpgBackgroundsSolidWhite
#define HDMI_MASK tpgColorMasksNoMask
#define HDMI_MOTION_SPEED 2
#define HDMI_COLOR_FORMAT tpgColorFormatRGB
#define HDMI_VIDEO_FORMAT vfbVideoFormatRGB8

#define VIDEO2MEM_RESET_CHANNEL 0
#define VIDEO2MEM_RESET_PIN 0
#define OPERATION_RESET_CHANNEL 0
#define OPERATION_RESET_PIN 1
#define MEM2VIDEO_RESET_CHANNEL 0
#define MEM2VIDEO_RESET_PIN 2

int main()
{
	XIicPs i2c;
	Gpio gpioReset;
	Tpg tpgVideo2Mem;
	Vfb vfbwrVideo2Mem;
	Vfb vfbrdOperation;
	Vfb vfbwrOperation;
	Vfb vfbrdMem2Video;
	volatile int* video_stream_not = (volatile int*)0x40012000;

	/*********************************************************************************************************************
	 * initialize all module
	 *********************************************************************************************************************/
	xil_printf("********** initialize all modules **********\r\n");

	xil_printf("gpio reset init\r\n");
	gpio_init(&gpioReset, (volatile int*) XPAR_GPIO_RESET_BASEADDR, 1);
	gpio_global_interrupt_disable(&gpioReset);

	xil_printf("TPG video2mem init\r\n");
	tpg_init(&tpgVideo2Mem, (volatile int*) XPAR_VIDEO2MEM_V_TPG_S_AXI_CTRL_BASEADDR);
	tpg_remove_reset(&tpgVideo2Mem);

	xil_printf("VFB write video2mem init\r\n");
	vfb_init(&vfbwrVideo2Mem, (volatile int*) XPAR_VIDEO2MEM_V_FRMBUF_WR_TPG_S_AXI_CTRL_BASEADDR);
	vfb_remove_reset(&vfbwrVideo2Mem);

	xil_printf("VFB read operation init\r\n");
	vfb_init(&vfbrdOperation, (volatile int*) XPAR_OPERATION_V_FRMBUF_RD_OPERATION_S_AXI_CTRL_BASEADDR);
	vfb_remove_reset(&vfbrdOperation);

	xil_printf("VFB write operation init\r\n");
	vfb_init(&vfbwrOperation, (volatile int*) XPAR_OPERATION_V_FRMBUF_WR_OPERATION_S_AXI_CTRL_BASEADDR);
	vfb_remove_reset(&vfbwrOperation);

	xil_printf("VFB read mem2video init\r\n");
	vfb_init(&vfbrdMem2Video, (volatile int*) XPAR_MEM2VIDEO_V_FRMBUF_RD_HDMI_S_AXI_CTRL_BASEADDR);
	vfb_remove_reset(&vfbrdMem2Video);

	/*********************************************************************************************************************
	 * configure video to memory
	 *********************************************************************************************************************/
	xil_printf("********** configure video to memory part **********\r\n");

	xil_printf("TPG video2mem config\r\n");
	tpg_autorestart_enable(&tpgVideo2Mem);
	tpg_global_interrupt_disable(&tpgVideo2Mem);
	tpg_set_width(&tpgVideo2Mem, HDMI_WIDTH);
	tpg_set_height(&tpgVideo2Mem, HDMI_HEIGHT);
	tpg_set_background_pattern_id(&tpgVideo2Mem, HDMI_DEFAULT_PATTERN);
	tpg_set_mask_id(&tpgVideo2Mem, HDMI_MASK);
	tpg_set_motion_speed(&tpgVideo2Mem, HDMI_MOTION_SPEED);
	tpg_set_color_format(&tpgVideo2Mem, HDMI_COLOR_FORMAT);

	xil_printf("VFB write video2mem config\r\n");
	vfb_autorestart_enable(&vfbwrVideo2Mem);
	vfb_global_interrupt_disable(&vfbwrVideo2Mem);
	vfb_set_width(&vfbwrVideo2Mem, HDMI_WIDTH);
	vfb_set_height(&vfbwrVideo2Mem, HDMI_HEIGHT);
	vfb_set_stride(&vfbwrVideo2Mem, HDMI_STRIDE);
	vfb_set_video_format(&vfbwrVideo2Mem, HDMI_VIDEO_FORMAT);
	vfb_set_video_address(&vfbwrVideo2Mem, OPERATION_SOURCE);

	xil_printf("start video2mem\r\n");
	tpg_start(&tpgVideo2Mem);
	vfb_start(&vfbwrVideo2Mem);

	/*********************************************************************************************************************
	 * configure memory to video
	 *********************************************************************************************************************/
	xil_printf("********** configure memory to video part **********\r\n");

	xil_printf("reset mem2video\r\n");
	gpio_set_pin_value(&gpioReset, MEM2VIDEO_RESET_CHANNEL, MEM2VIDEO_RESET_PIN, 0);
	usleep(100*1000);
	gpio_set_pin_value(&gpioReset, MEM2VIDEO_RESET_CHANNEL, MEM2VIDEO_RESET_PIN, 1);

	xil_printf("VFB read mem2video config\r\n");
	vfb_autorestart_enable(&vfbrdMem2Video);
	vfb_global_interrupt_disable(&vfbrdMem2Video);
	vfb_set_width(&vfbrdMem2Video, HDMI_WIDTH);
	vfb_set_height(&vfbrdMem2Video, HDMI_HEIGHT);
	vfb_set_stride(&vfbrdMem2Video, HDMI_STRIDE);
	vfb_set_video_format(&vfbrdMem2Video, HDMI_VIDEO_FORMAT);
	vfb_set_video_address(&vfbrdMem2Video, OPERATION_DESTINATION);

	xil_printf("start mem2video\r\n");
	vfb_start(&vfbrdMem2Video);

	xil_printf("Config HDMI\r\n");
	i2c_ps_master_init(&i2c, XPAR_PS7_I2C_0_DEVICE_ID, 100 * 1000);
	sii9022_init(&i2c);

	/*********************************************************************************************************************
	 * configure operation
	 *********************************************************************************************************************/
	xil_printf("********** configure operation part **********\r\n");

	xil_printf("VFB read operation config\r\n");
	vfb_autorestart_enable(&vfbrdOperation);
	vfb_global_interrupt_disable(&vfbrdOperation);
	vfb_set_width(&vfbrdOperation, HDMI_WIDTH);
	vfb_set_height(&vfbrdOperation, HDMI_HEIGHT);
	vfb_set_stride(&vfbrdOperation, HDMI_STRIDE);
	vfb_set_video_format(&vfbrdOperation, HDMI_VIDEO_FORMAT);
	vfb_set_video_address(&vfbrdOperation, OPERATION_SOURCE);

	xil_printf("VFB write operation config\r\n");
	vfb_autorestart_enable(&vfbwrOperation);
	vfb_global_interrupt_disable(&vfbwrOperation);
	vfb_set_width(&vfbwrOperation, HDMI_WIDTH);
	vfb_set_height(&vfbwrOperation, HDMI_HEIGHT);
	vfb_set_stride(&vfbwrOperation, HDMI_STRIDE);
	vfb_set_video_format(&vfbwrOperation, HDMI_VIDEO_FORMAT);
	vfb_set_video_address(&vfbwrOperation, OPERATION_DESTINATION);

	xil_printf("start operation\r\n");
	vfb_start(&vfbrdOperation);
	video_stream_not[0] = 1;
	vfb_start(&vfbwrOperation);

	/*********************************************************************************************************************
	 * configurations end
	 *********************************************************************************************************************/
	usleep(1 * 1000 * 1000);
	xil_printf("********** configurations end **********\r\n");

	int pattern = 15;
	while(1)
	{
		xil_printf("set pattern ID to: %d\r\n", pattern);
		xil_printf("tpg video2mem status is: %d, %d, %d\r\n",
				tpg_is_done(&tpgVideo2Mem),
				tpg_is_idle(&tpgVideo2Mem),
				tpg_is_ready(&tpgVideo2Mem));
		tpg_set_background_pattern_id(&tpgVideo2Mem, pattern);
		xil_printf("vfb write video2mem status is: %d, %d, %d\r\n",
				vfb_is_done(&vfbwrVideo2Mem),
				vfb_is_idle(&vfbwrVideo2Mem),
				vfb_is_ready(&vfbwrVideo2Mem));
		xil_printf("vfb read operation status is: %d, %d, %d\r\n",
				vfb_is_done(&vfbrdOperation),
				vfb_is_idle(&vfbrdOperation),
				vfb_is_ready(&vfbrdOperation));
		xil_printf("vfb write operation status is: %d, %d, %d\r\n",
				vfb_is_done(&vfbwrOperation),
				vfb_is_idle(&vfbwrOperation),
				vfb_is_ready(&vfbwrOperation));
		xil_printf("vfb read mem2video status is: %d, %d, %d\r\n",
				vfb_is_done(&vfbrdMem2Video),
				vfb_is_idle(&vfbrdMem2Video),
				vfb_is_ready(&vfbrdMem2Video));
		tpg_set_background_pattern_id(&tpgVideo2Mem, pattern);
		xil_printf("insert new pattern ID:\r\n");
		getchar();
		if(pattern == 9)
		{
			pattern = 15;
		}
		else if(pattern >= 15)
		{
			pattern = 1;
		}
		else
		{
			pattern ++;
		}
	}
}
