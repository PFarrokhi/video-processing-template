#ifndef SRC_SII9022_INIT_H_
#define SRC_SII9022_INIT_H_

#include "../I2C_PS/i2c_ps.h"

int sii9022_init(XIicPs* i2c);

#endif
